install.packages('rvest')
library(rvest)

url <- 'https://www.thegoodguys.com.au/SearchDisplay?categoryId=&storeId=900&catalogId=30000&langId=-1&sType=SimpleSearch&resultCatEntryType=2&showResultsPage=true&searchSource=Q&pageView=&beginIndex=0&orderBy=0&pageSize=60&searchTerm=refrigerator'

page_source <- read_html(url)

css <- page_source %>% html_nodes('.product-tile-name')
xpath <- page_source %>% html_nodes(xpath = '//*[contains(concat( " ", @class, " " ), concat( " ", "product-tile-name", " " ))]')

css <- css[1:20]
htxt <- css %>% html_text()

df_ref <- data.frame(ref_top20 = htxt)
df_ref
